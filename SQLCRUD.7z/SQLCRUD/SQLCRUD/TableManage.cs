﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace SQLCRUD
{
    public class TableManage
    {
        //field
        private SqlConnection _connection; //_connection มาจาก class SQLconn

        //default constructor
        public TableManage(SqlConnection connection)
        {
            _connection = connection;
        }

        //insert data to table
        public void InsertData(int tsid, string sp_id, string sp_name, int sp_qty, string sp_mc, string at, string mark)
        {
            string excute = "INSERT INTO crud_op(tsid, sp_id, sp_name, sp_qty, sp_mc, at, mark) VALUES (@tsid, @sp_id, @sp_name, @sp_qty, @sp_mc, @at, @mark)";
            try
            {
                using (SqlCommand cmd = new SqlCommand(excute, _connection))
                {
                    {
                        cmd.Parameters.AddWithValue("@tsid", tsid);
                        cmd.Parameters.AddWithValue("@sp_id", sp_id);
                        cmd.Parameters.AddWithValue("@sp_name", sp_name);
                        cmd.Parameters.AddWithValue("@sp_qty", sp_qty);
                        cmd.Parameters.AddWithValue("@sp_mc", sp_mc);
                        cmd.Parameters.AddWithValue("@at", at);
                        cmd.Parameters.AddWithValue("@mark", mark);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex)
            {
                throw new Exception("ไม่สามารถเพิ่มข้อมูลได้: " + ex.Message);
            }
        }
    }

}
