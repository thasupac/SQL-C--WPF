﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using Microsoft.Data.SqlClient;

namespace SQLCRUD
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //เก็บ connection ที่ได้รับจาก class SQLconn

        //timmer
        private DispatcherTimer timer;
        private SqlConnection? connection; // เก็บ connection ไว้
        private TableManage? db;
        public MainWindow()
        {
            InitializeComponent();
            //load gui
            this.Loaded += MainWindow_Loaded;  // รอให้หน้าต่างแสดงก่อนค่อยเชื่อมต่อ

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);  // ตั้งเวลาให้ tick ทุก 1 วินาที
            timer.Tick += Timer_Tick;                   // ใส่ event handler
            timer.Start();


        }
        private void Timer_Tick(object? sender, EventArgs e)
        {
            txttime.Text = DateTime.Now.ToString("HH:mm:ss");  // แสดงชั่วโมง:นาที:วินาที
                                                               // หรือถ้าอยากแสดงวันที่ด้วย
                                                              // txtTime.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
        }
        private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            await BackgroundConn();
        }
        public async Task BackgroundConn()
        {
            SQLconn dbCONN = new SQLconn();
            try
            {
                // GetConnection() จาก class SQLconn
                connection = await Task.Run(() => dbCONN.GetConnection());
                // สร้าง TableManage ครั้งเดียว
                db = new TableManage(connection);

                // รอ UI โหลดเต็มก่อนค่อยแจ้ง
                await Task.Delay(500); // ✅ รอ 0.5 วินาที
                Dispatcher.Invoke(() =>
                {
                    sql_status.Text = "SQL : Connected";
                });
            }
            catch (Exception ex)

            {
                await Task.Delay(500); // ✅ รอ 0.5 วินาทีก่อนแสดง error

                Dispatcher.Invoke(() =>
                {
                    sql_status.Text = "SQL : Fail Connect - " + ex.Message;
                });
            }
        }
        private void spare_save_Click(object sender, RoutedEventArgs e)
        {
            
            try
            {
                if (connection == null || connection.State != System.Data.ConnectionState.Open)
                {
                    MessageBox.Show("ยังไม่ได้เชื่อมต่อฐานข้อมูล");
                    return;
                }
                int tsid = int.Parse(DateTime.Now.ToString("HHmmss"));
                string sp_id = sp_idbox.Text;
                string sp_name = sp_namebox.Text;
                int sp_qty;
                if (!int.TryParse(sp_qtybox.Text, out sp_qty))
                {
                    sp_qty = 0; // กำหนด default หากแปลงไม่สำเร็จ
                    MessageBox.Show("กรุณากรอกจำนวนที่ถูกต้อง");
                }
                string sp_mc = sp_namebox.Text;
                string at_location = at_locationbox.Text;
                string mark = markbox.Text;
                // ตรวจสอบช่องว่าง หรือ null ว่ากรอกครบทุกช่องไหม
                if (string.IsNullOrWhiteSpace(sp_id) ||
                    string.IsNullOrWhiteSpace(sp_name) ||
                    string.IsNullOrWhiteSpace(sp_mc) ||
                    string.IsNullOrWhiteSpace(at_location))
                {
                    MessageBox.Show("กรุณากรอกข้อมูลให้ครบทุกช่อง");
                    return; // หยุดทำงาน
                }
                if (db != null)
                {
                    db.InsertData(tsid, sp_id, sp_name, sp_qty, sp_mc, at_location, mark);
                    MessageBox.Show("บันทึกข้อมูลสำเร็จ");
                    Resetui();
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("เกิดข้อผิดพลาด: " + ex.Message);
            }            
        }
        private void Resetui()
        {
            sp_idbox.Text = string.Empty;
            sp_namebox.Text = string.Empty;
            sp_qtybox.Text = string.Empty;
            sp_mcbox.Text = string.Empty;
            at_locationbox.Text = string.Empty;
            markbox.Text = string.Empty;
        }
        // 🔴 เมื่อปิดหน้าต่าง ให้ปิด SQL Connection ด้วย
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);

            if (connection != null && connection.State == System.Data.ConnectionState.Open)
            {
                connection.Close();
                connection.Dispose();
            }
        }
        private void search_Click(object sender, RoutedEventArgs e)
        {
            string selectedValue = search_type.Text.Trim();
            if (connection == null || connection.State != System.Data.ConnectionState.Open)
            {
                MessageBox.Show("ยังไม่ได้เชื่อมต่อฐานข้อมูล");
                return;
            }
            switch (selectedValue)
            {
                case "All":
                    if (db != null)
                    {
                        var dt = db.GetAll();  // ดึงข้อมูลทั้งหมดเป็น DataTable
                        spareDataGrid.ItemsSource = dt.DefaultView;  // bind ข้อมูลลง DataGrid
                    }
                    break;


                case "Machine":
                    
                    break;

                case "ID":
                    
                    break;

                default:
                    MessageBox.Show("กรุณาเลือก Search_type");
                    break;
            }
        }

        private void spareDataGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (spareDataGrid.SelectedItem == null)
                return;

            // แปลง SelectedItem เป็น DataRowView (เพราะ ItemsSource เป็น DataView)
            var rowView = spareDataGrid.SelectedItem as System.Data.DataRowView;
            if (rowView != null)
            {
                // สมมติอยากเอาข้อมูลคอลัมน์ sp_id มาแสดง
                string? sp_id = rowView["sp_id"].ToString();
                string? sp_name = rowView["sp_name"].ToString();

                // เปิดหน้าต่างใหม่ พร้อมส่งค่า
                Updatespare detailWindow = new Updatespare();
                detailWindow.ShowDialog(); // หรือ .Show()

                //MessageBox.Show($"คุณดับเบิลคลิกที่ Spare ID: {sp_id}\nชื่อ: {sp_name}");
            }
        }
        private void spareDataGrid_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            // หาตัว DataGridRow ที่ถูกคลิกขวา
            DependencyObject dep = (DependencyObject)e.OriginalSource;

            while (dep != null && !(dep is DataGridRow))
            {
                dep = VisualTreeHelper.GetParent(dep);
            }

            if (dep is DataGridRow row)
            {
                row.IsSelected = true;         // ไฮไลท์แถวที่ถูกคลิกขวา
                spareDataGrid.SelectedItem = row.Item;  // กำหนด SelectedItem
            }
        }
        private void delete_data_Click(object sender, RoutedEventArgs e)
        {
            if (spareDataGrid.SelectedItem == null)
            {
                MessageBox.Show("กรุณาเลือกแถวที่ต้องการลบข้อมูล");
                return;
            }
            var rowView = spareDataGrid.SelectedItem as System.Data.DataRowView;
            if (rowView != null)
            {
                string? sp_id = rowView["sp_id"].ToString();
                var result = MessageBox.Show($"ต้องการลบข้อมูล Spare_ID = {sp_id} หรือไม่?", "ยืนยันการลบ", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (connection == null || connection.State != System.Data.ConnectionState.Open)
                {
                    MessageBox.Show("ยังไม่ได้เชื่อมต่อฐานข้อมูล");
                    return;
                }
                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        if(sp_id != null&& db!=null)
                        {
                            db.Deletedata(sp_id);
                            //// โหลดข้อมูลใหม่มาแสดง
                            var dt = db.GetAll();
                            spareDataGrid.ItemsSource = dt.DefaultView;
                        }
                        MessageBox.Show("ลบข้อมูลสำเร็จ");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("เกิดข้อผิดพลาด: " + ex.Message);
                    }
                }
            }
        }

        private void key_word_try_TextChanged(object sender, TextChangedEventArgs e)
        {
            string keyword = key_word_try.Text.Trim();

            if (string.IsNullOrEmpty(keyword))
            {
                // ถ้า textbox ว่าง โหลดข้อมูลทั้งหมด
                if (db != null)
                {
                    var allData = db.GetAll();
                    spareDataGrid.ItemsSource = allData.DefaultView;
                }
                
            }
            else
            {
                try
                {
                    // ดึงข้อมูลจากฐานข้อมูลโดยกรองคำที่พิมพ์
                    if (db!=null)
                    {
                        var filteredData = db.KeywordSearch(keyword);
                        spareDataGrid.ItemsSource = filteredData.DefaultView;
                    }
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
    }
}