﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using Microsoft.Data.SqlClient;

namespace SQLCRUD
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //เก็บ connection ที่ได้รับจาก class SQLconn

        //timmer
        private DispatcherTimer timer;
        private SqlConnection? connection; // เก็บ connection ไว้
        public MainWindow()
        {
            InitializeComponent();
            //load gui
            this.Loaded += MainWindow_Loaded;  // รอให้หน้าต่างแสดงก่อนค่อยเชื่อมต่อ

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);  // ตั้งเวลาให้ tick ทุก 1 วินาที
            timer.Tick += Timer_Tick;                   // ใส่ event handler
            timer.Start();


        }
        private void Timer_Tick(object? sender, EventArgs e)
        {
            txttime.Text = DateTime.Now.ToString("HH:mm:ss");  // แสดงชั่วโมง:นาที:วินาที
                                                               // หรือถ้าอยากแสดงวันที่ด้วย
                                                              // txtTime.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
        }
        private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            await BackgroundConn();
        }
        public async Task BackgroundConn()
        {
            SQLconn dbCONN = new SQLconn();
            try
            {
                // GetConnection() จาก class SQLconn
                connection = await Task.Run(() => dbCONN.GetConnection());
                // รอ UI โหลดเต็มก่อนค่อยแจ้ง
                await Task.Delay(500); // ✅ รอ 0.5 วินาที
                Dispatcher.Invoke(() =>
                {
                    sql_status.Text = "SQL : Connected";
                });
            }
            catch (Exception ex)

            {
                await Task.Delay(500); // ✅ รอ 0.5 วินาทีก่อนแสดง error

                Dispatcher.Invoke(() =>
                {
                    sql_status.Text = "SQL : Fail Connect - " + ex.Message;
                });
            }
        }

        private void spare_save_Click(object sender, RoutedEventArgs e)
        {
            
            try
            {
                if (connection == null || connection.State != System.Data.ConnectionState.Open)
                {
                    MessageBox.Show("ยังไม่ได้เชื่อมต่อฐานข้อมูล");
                    return;
                }
                int tsid = int.Parse(DateTime.Now.ToString("HHmmss"));
                string sp_id = sp_idbox.Text;
                string sp_name = sp_namebox.Text;
                int sp_qty;
                if (!int.TryParse(sp_qtybox.Text, out sp_qty))
                {
                    sp_qty = 0; // กำหนด default หากแปลงไม่สำเร็จ
                    MessageBox.Show("กรุณากรอกจำนวนที่ถูกต้อง");
                }
                string sp_mc = sp_namebox.Text;
                string at_location = at_locationbox.Text;
                string mark = markbox.Text;
                // ตรวจสอบช่องว่าง หรือ null ว่ากรอกครบทุกช่องไหม
                if (string.IsNullOrWhiteSpace(sp_id) ||
                    string.IsNullOrWhiteSpace(sp_name) ||
                    string.IsNullOrWhiteSpace(sp_mc) ||
                    string.IsNullOrWhiteSpace(at_location))
                {
                    MessageBox.Show("กรุณากรอกข้อมูลให้ครบทุกช่อง");
                    return; // หยุดทำงาน
                }
                // class obj = new class(parameter ส่งไปที่ class TableManage)
                TableManage savedata = new TableManage(connection);
                //obj.method(parameter)
                savedata.InsertData(tsid, sp_id, sp_name, sp_qty, sp_mc, at_location, mark);
                MessageBox.Show("บันทึกข้อมูลสำเร็จ");
            }
            catch (Exception ex)
            {
                MessageBox.Show("เกิดข้อผิดพลาด: " + ex.Message);
            }
            
        }
        // 🔴 เมื่อปิดหน้าต่าง ให้ปิด SQL Connection ด้วย
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);

            if (connection != null && connection.State == System.Data.ConnectionState.Open)
            {
                connection.Close();
                connection.Dispose();
            }
        }
    }
}