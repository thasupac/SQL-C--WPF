﻿using System;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Configuration; // สำหรับอ่าน config
namespace SQLCRUD
{
    public class SQLconn
    {
        private string connectionString;

        public SQLconn() //default constructor
        {
            // อ่าน connection string จาก app.config
            connectionString = ConfigurationManager.ConnectionStrings["MyDbConnection"].ConnectionString;
        }
        public SqlConnection GetConnection()
        {

            var conn = new SqlConnection(connectionString);
            conn.Open();
            return conn;
        }
    }
}
